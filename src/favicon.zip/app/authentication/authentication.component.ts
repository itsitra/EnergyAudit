import { Component, OnInit } from "@angular/core";

@Component({
  selector: "ngx-authentication",
  templateUrl: "./authentication.component.html",
  styleUrls: ["./authentication.component.scss"],
})
export class AuthenticationLayout implements OnInit {
  constructor() {}

  ngOnInit() {}
}
