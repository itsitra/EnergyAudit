/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
export const environment = {
  production: true,
  apiurl: "http://lab.sitraonline.org.in/energyauditapi/index.php/api",
  //appurl:'https://localhost:44327/#'
};
